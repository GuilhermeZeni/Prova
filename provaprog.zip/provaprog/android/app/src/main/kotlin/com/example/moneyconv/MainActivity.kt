package com.example.moneyconv

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
